source="./jco/*"
target="./dist"
cp -vr $source $target
