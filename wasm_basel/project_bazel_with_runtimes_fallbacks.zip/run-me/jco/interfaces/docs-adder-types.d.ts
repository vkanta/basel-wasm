export namespace DocsAdderTypes {
}
export interface Operants {
  a: number,
  b: number,
}
