export namespace WasiClocksWallClock {
}
export interface Datetime {
  seconds: bigint,
  nanoseconds: number,
}
