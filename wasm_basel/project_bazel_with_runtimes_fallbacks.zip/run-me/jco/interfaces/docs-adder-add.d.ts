export namespace DocsAdderAdd {
  export { Addresource };
}
import type { Operants } from './docs-adder-types.js';
export { Operants };

export class Addresource {
  constructor()
  add(operants: Operants): number;
}
