export namespace WasiIoError {
  export { Error };
}

export class Error {
}
