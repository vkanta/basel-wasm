export namespace DocsCalculateCalculate {
  export function evalExpression(expr: string): number;
}
