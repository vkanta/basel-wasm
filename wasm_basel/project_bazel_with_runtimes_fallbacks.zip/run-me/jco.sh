rm -fr ./jco
jco transpile hello.wasm -o ./jco --tla-compat --no-namespaced-exports --tracing

