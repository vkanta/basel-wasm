# WASI Preview1 Adapters

Place the appropriate adapter from the Wasmtime releases in this directory and add it to git:

- `wasi_snapshot_preview1.command.wasm` (for command-style modules)
- or `wasi_snapshot_preview1.reactor.wasm` (for reactor-style)

Download from: https://github.com/bytecodealliance/wasmtime/releases
