#!/usr/bin/env bash
set -euo pipefail
echo 'Artifacts ready after build: bazel-bin/adder/adder.component.wasm, bazel-bin/calculate/calculate.component.wasm'
