fn main(){ let (a,b)=(2,3); println!("adder: {} + {} = {}", a,b,a+b);}
