fn main(){ let x=5; println!("calculate: eval({}) = {}", x, x+1);}
